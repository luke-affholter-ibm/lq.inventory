package com.javaoo.store.drivers;

import java.util.Date;
import com.javaoo.store.Item;
import com.javaoo.store.Book;
import com.javaoo.store.CD;
import com.javaoo.store.Artist;

public class InventoryDriver {
	
	private static Item[] myInventory = new Item[50];

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		myInventory[0] = new Book("book1", 24.95, 2, "me", "also me", "random");
		myInventory[1] = new Book("book2", 24.95, 2, "me", "also me", "random");
		myInventory[2] = new Book("book3", 24.95, 2, "me", "also me", "random");
		myInventory[3] = new Book("book4", 24.95, 2, "me", "also me", "random");
		myInventory[4] = new Book("book5", 24.95, 2, "me", "also me", "random");
		myInventory[5] = new CD("cd1", 24.95, 2, new Artist("me"), new Date("07/07/2007"));
		myInventory[5] = new CD("cd2", 24.95, 2, new Artist("me"), new Date("07/07/2007"));
		
	}

}

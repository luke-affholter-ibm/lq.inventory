package com.javaoo.store;

public class Item {
	
	private String title;
	private double price;
	private double quantity;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}
	
	public Item(String inputTitle, double inputPrice, double inputQuantity) {
		setTitle(inputTitle);
		setPrice(inputPrice);
		setQuantity(inputQuantity);
	}
	
	public Item() {
		
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String inputTitle) {
		this.title = inputTitle;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double inputPrice) {
		this.price = inputPrice;
	}

	public double getQuantity() {
		return quantity;
	}

	public void setQuantity(double inputQuantity) {
		this.quantity = inputQuantity;
	}

}

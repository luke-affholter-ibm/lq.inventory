package com.javaoo.store;

import java.util.*;
import java.io.*;
import java.lang.Double;

public class BookEx {
	
	private static Book example;
	private static List<Book> books = new ArrayList();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String location = "C:\\Users\\Student\\eclipse-workspace\\ClassExercises\\src\\com\\javaoo\\store\\books.txt";
		
		try {
			readBooksFromFile(location);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		for (Book book : books) {
			System.out.println(book.getTitle());
		}
		
	}
	
	public static List<Book> readBooksFromFile(String name) throws FileNotFoundException {
		//List<Book> books = new ArrayList();
		try {
			FileInputStream inFile = new FileInputStream(name);
			InputStreamReader inReader = new InputStreamReader(inFile);
			LineNumberReader lineReader = new LineNumberReader(inReader);
			
			String line = lineReader.readLine();
			String title = "";
			String author = "";
			double price = 0;
			int count = 0;
			while (line != null) {
				System.out.println(line);
				if (count == 0) {
					title = line;
				}
				if (count == 1) {
					author = line;
				}
				if (count == 2) {
					price = Double.parseDouble(line);
					System.out.println(title);
					System.out.println(author);
					System.out.println(price);
					example = new Book(title, price, 5, author, null, "NON-FICTION");
					books.add(example);
				}
				line = lineReader.readLine();
				count++;
			}
			lineReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found.");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Input stream error.");
			e.printStackTrace();
		}
		return books;
		
		
		
	}

}

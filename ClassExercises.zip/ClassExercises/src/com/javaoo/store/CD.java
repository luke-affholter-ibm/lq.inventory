package com.javaoo.store;

import java.util.Date;

public class CD extends Item{
	
	private Artist artist;
	private Date releaseDate;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public CD(String inputTitle, double inputPrice, double inputQuantity, Artist inputArtist, Date inputRelease) {
		super.setTitle(inputTitle);
		super.setPrice(inputPrice);
		super.setQuantity(inputQuantity);
		setArtist(inputArtist);
		setReleaseDate(inputRelease);
	}

	public Artist getArtist() {
		return artist;
	}

	public void setArtist(Artist artist) {
		this.artist = artist;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

}

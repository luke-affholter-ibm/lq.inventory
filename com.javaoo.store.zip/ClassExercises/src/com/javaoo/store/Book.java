package com.javaoo.store;

public class Book extends Item{
	
	private String author;
	private String publisher;
	private String category;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public Book(String inputTitle, double inputPrice, double inputQuantity, String inputAuthor, String inputPublisher, String inputCategory) {
		super.setTitle(inputTitle);
		super.setPrice(inputPrice);
		super.setQuantity(inputQuantity);
		setAuthor(inputAuthor);
		setPublisher(inputPublisher);
		setCategory(inputCategory);
	}
	
	public Book(String inputAuthor, String inputPublisher, String inputCategory) {
		setAuthor(inputAuthor);
		setPublisher(inputPublisher);
		setCategory(inputCategory);
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}

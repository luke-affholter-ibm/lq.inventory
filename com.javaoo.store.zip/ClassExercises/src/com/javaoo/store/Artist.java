package com.javaoo.store;

import java.util.Map;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class Artist {
	
	private String name;
	private SortedSet<String> memberNames;
	private Map<String, SortedSet<String>> memberInstruments;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}
	
	public Artist() {
		memberNames = new TreeSet<String>();
		memberInstruments = new TreeMap<String, SortedSet<String>>();
	}
	
	public Artist(String inputName) {
		this();
		setName(inputName);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public SortedSet<String> getMemberNames() {
		return memberNames;
	}

	public void setMemberNames(SortedSet<String> memberNames) {
		this.memberNames = memberNames;
	}

	public Map<String, SortedSet<String>> getMemberInstruments() {
		return memberInstruments;
	}

	public void setMemberInstruments(Map<String, SortedSet<String>> memberInstruments) {
		this.memberInstruments = memberInstruments;
	}
	
	public void addMember(String name, SortedSet<String> instruments) {
		memberNames.add(name);
		memberInstruments.put(name,  instruments);
	}
	

}

package com.lq.testcases;

public class ClassToTest {

	public boolean methodToTest () {
		return true;
	}
	
}

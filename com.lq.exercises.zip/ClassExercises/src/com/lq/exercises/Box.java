/**
 * 
 */
package com.lq.exercises;

/**
 * @author Student
 *
 */
public class Box {

	private double height;
	private double width;
	private double length;
	
	
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		Box box1 = new Box(12.0, 11.2, 16.7);
		Box box2 = new Box(10.0);
		
		box1.printBox();
		box2.printBox();
		*/

	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		if (height > 0) {
			this.height = height;
		} else {
			System.out.println("Value must be greater than zero.");
		}
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		if (width > 0) {
			this.width = width;
		} else {
			System.out.println("Value must be greater than zero.");
		}
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		if (length > 0) {
			this.length = length;
		} else {
			System.out.println("Value must be greater than zero.");
		}
	}

	Box(double h, double w, double l) {
		if ((h > 0) && (w > 0) && (l > 0) ) {
			setHeight(h);
			setWidth(w);
			setLength(l);
		} else {
			System.out.println("Values must be greater than zero.");
		}
	}
	
	Box(double input) {
		if (input > 0) {
			setHeight(input);
			setWidth(input);
			setLength(input);
		} else {
			System.out.println("Values must be greater than zero.");
		}
	}
	
	public double getVolume() {
		double volume = (getHeight() * getWidth() * getLength());
		return volume;
	}
	
	public double getSurfaceArea() {
		double area1 = getHeight() * getWidth();
		double area2 = getHeight() * getLength();
		double area3 = getWidth() * getLength();
		double surface = ((area1 * 2)  + (area2 * 2) + (area3 * 2));
		return surface;
	}
	
	public void printBox() {
		double h = getHeight();
		double w = getWidth();
		double l = getLength();
		if ((h <= 0) || (w <= 0) || (l <= 0)) {
			System.out.println("Invalid inputs. Check for arguments less than or equal to zero.");
			return;
		} else {
			System.out.println("Length = " + l);
			System.out.println("Width = " + w);
			System.out.println("height = " + h);
			System.out.println("Volume = " + getVolume());
			System.out.println("Surface Area = " + getSurfaceArea());
		}
		
	}
}

/**
 * 
 */
package com.lq.exercises;

/**
 * @author Student
 *
 */
public class Lab3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		String[] daysOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
		for (int i = 0; i < daysOfWeek.length; i++) {
			System.out.println(daysOfWeek[i]);
		}
		for (int i = 0; i < daysOfWeek.length; i++) {
			System.out.println(daysOfWeek[(daysOfWeek.length - 1) - i]);
		}
		
		int x = 0;
		while (x<21) {
			if (x % 2 == 0) {
				System.out.println(x);
				x++;
				continue;
			} else {
			x++;
			continue;
			}
		}
		for (int i = 1; i < 101; i++) {
			if (!((i > 49) && (i < 61))) {
				System.out.println(i);
			}
		}
		*/
		
		int[] daysInMonths = new int[12];
		String[] monthNames = new String[12];
		
		daysInMonths[0] = 31;
		daysInMonths[1] = 28;
		daysInMonths[2] = 31;
		daysInMonths[3] = 30;
		daysInMonths[4] = 31;
		daysInMonths[5] = 30;
		daysInMonths[6] = 31;
		daysInMonths[7] = 31;
		daysInMonths[8] = 30;
		daysInMonths[9] = 31;
		daysInMonths[10] = 30;
		daysInMonths[11] = 31;
		
		monthNames[0] = "January";
		monthNames[1] =  "February";
		monthNames[2] = "March";
		monthNames[3] = "April";
		monthNames[4] =  "May";
		monthNames[5] = "June";
		monthNames[6] = "July";
		monthNames[7] =  "August";
		monthNames[8] = "September";
		monthNames[9] = "October";
		monthNames[10] =  "November";
		monthNames[11] = "December";
		
		int y = 1;
		int days = 0;
		String month = "";
		System.out.println("The following months have 31 days: ");
		while (y <= 12) {
			switch (y) {
			case 0: days = daysInMonths[y-1];
					month = monthNames[y-1];
				break;
			case 1: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
			case 2: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
			case 3: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
			case 4: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
			case 5: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
			case 6: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
			case 7: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
			case 8: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
			case 9: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
			case 10: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
			case 11: days = daysInMonths[y-1];
			month = monthNames[y-1];
				break;
				default: break;
			}
			if (days == 31) {
				System.out.println(month);
			}
			y++;
		}

	}

}

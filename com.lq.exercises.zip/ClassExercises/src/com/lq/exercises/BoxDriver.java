/**
 * 
 */
package com.lq.exercises;

/**
 * @author Student
 *
 */
public class BoxDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Box box1 = new Box(5, 6, 7);
		Box box2 = new Box(10);
		
		System.out.println("Box1 dimensions:");
		box1.printBox();
		System.out.println("Box2 dimensions:");
		box2.printBox();
		
		box1.setLength(3);
		box1.setWidth(4);
		box1.setHeight(5);
		box1.printBox();
		
		box1.setLength(-5);
		box1.setWidth(-5);
		box1.setHeight(-5);
		box1.printBox();
		
		

	}

}

/**
 * 
 */
package com.lq.exercises;

/**
 * @author Student
 *
 */
public class Cube extends Box {


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	Cube(double input) {
		super(input);
	}
	
	public void setHeight(double input) {
		if (input > 0) {
			super.setHeight(input);
			super.setWidth(input);
			super.setLength(input);
		} else {
			System.out.println("Values must be greater than zero.");
		}
	}
	
	public void setWidth(double input) {
		if (input > 0) {
			super.setHeight(input);
			super.setWidth(input);
			super.setLength(input);
		} else {
			System.out.println("Values must be greater than zero.");
		}
	}
	
	public void setLength(double input) {
		if (input > 0) {
			super.setHeight(input);
			super.setWidth(input);
			super.setLength(input);
		} else {
			System.out.println("Values must be greater than zero.");
		}
	}
	
	public void setSide(double input) {
		if (input > 0) {
			super.setHeight(input);
			super.setWidth(input);
			super.setLength(input);
		} else {
			System.out.println("Values must be greater than zero.");
		}
	}
	
	public double getSide() {
		return super.getHeight();
	}

}
